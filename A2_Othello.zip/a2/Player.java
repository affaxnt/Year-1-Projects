package a2;

public class Player {
    private String name;
    private char colour;

    public Player(String name, char colour) {
        this.name = name;
        this.colour = colour;
    }

    public String getName() {
        return name;
    }

    public char getColour() {
        return colour;
    }
}
